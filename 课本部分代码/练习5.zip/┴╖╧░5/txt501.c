#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<stdlib.h>

int main(){
char ch;
int i;
printf("---输入0退出转换---输入1进行转换---\n");
scanf("%d",&i);
if(i==0){
	return 0;
}
else if(i==1){
	printf("请输入一个字符：\n");
	scanf("%c",&ch);
	if (ch >= 'a' && ch <= 'z'){
		ch -= 32;
		printf("%c\n", ch);
	}
	else if (ch >= 'A' && ch <= 'Z'){
		ch += 32;
		printf("%c\n", ch);
	}
	else{
		printf("输入的不是大写或者小写字母\n");
	}
}

return 0;
}
